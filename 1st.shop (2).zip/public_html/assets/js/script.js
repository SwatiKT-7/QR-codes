// assets/js/script.js
document.addEventListener('DOMContentLoaded', function() {
    console.log("Appointment System Loaded!");
    
    // Add your JS code for interactivity here
});
