<?php
session_start();
require '../config/db.php';

// Get appointment details
$appointment_id = isset($_GET['appointment_id']) ? $_GET['appointment_id'] : '';
$appt = $conn->query("SELECT * FROM appointments WHERE id = '$appointment_id'")->fetch_assoc();

// Generate a new 6-digit verification code
$verification_code = rand(100000, 999999);
$appt_time = $appt['appointment_time'];

// Save verification code in the database
$conn->query("UPDATE appointments SET verification_code = '$verification_code' WHERE id = '$appointment_id'");

// Generate verification link
$verification_link = "https://vipranshu.shop/host/verify_code.php?code=" . urlencode($verification_code);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Generate QR Code</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
</head>
<body>
    <h2>Verification Code: <?= $verification_code ?></h2>
    <h4>Appointment Time: <?= $appt_time ?></h4>
    <p>Scan the QR code to verify:</p>

    <!-- QR Code will be generated here -->
    <div id="qrcode"></div>

    <p>Or click <a href="<?= $verification_link ?>" target="_blank"><?= $verification_link ?></a> to verify.</p>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            var qrElement = document.getElementById("qrcode");
            var verificationLink = "<?= $verification_link ?>"; // Full verification URL

            console.log("QR Code Data: ", verificationLink); // Debugging

            if (qrElement && verificationLink) {
                new QRCode(qrElement, {
                    text: verificationLink, // Encode full URL, not just the code
                    width: 150,
                    height: 150
                });
            } else {
                console.error("Error: QR Code element or verification link is missing.");
            }
        });
    </script>
</body>
</html>
