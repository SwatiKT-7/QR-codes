<?php
session_start();
require '../config/db.php';

// Redirect if not logged in or not a host
if (!isset($_SESSION['user_id']) || $_SESSION['type'] !== 'host') {
    header("Location: ../auth/login.php");
    exit();
}

$host_id = $_SESSION['user_id'];
$username = $_SESSION['username'];

// Fetch appointments
$appointments = $conn->query("SELECT a.id, u.username as user_name, u.email, u.phone_no, u.photo, 
                              a.appointment_time, a.status 
                              FROM appointments a 
                              JOIN login u ON a.user_id = u.id 
                              WHERE a.host_id = '$host_id'");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Host Dashboard</title>

    <!-- Bootstrap 5 -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>

    <style>
        body {
            background: #f3f4f6;
            padding: 20px;
        }
        .container {
            max-width: 900px;
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        .card {
            border-radius: 12px;
            padding: 15px;
            margin-bottom: 15px;
        }
        .user-info img {
            border-radius: 50%;
            width: 50px;
            height: 50px;
            object-fit: cover;
            margin-right: 10px;
        }
        .appointment-card {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 10px;
        }
        .actions {
            display: flex;
            flex-direction: column;
            gap: 5px;
        }
        @media (max-width: 768px) {
            .appointment-card {
                flex-direction: column;
                align-items: flex-start;
            }
            .actions {
                flex-direction: row;
                flex-wrap: wrap;
                gap: 10px;
                width: 100%;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="text-lg font-bold">Welcome, <?= $username ?> (Host)</h2>
        <a href="../logout.php" class="btn btn-danger btn-sm">Logout</a>
    </div>

    <h4 class="text-primary">Pending Appointment Requests</h4>
    <div class="row">
        <?php while ($appt = $appointments->fetch_assoc()): ?>
            <?php if ($appt['status'] == 'pending'): ?>
                <div class="col-md-6">
                    <div class="card shadow-sm">
                        <div class="appointment-card">
                            <div class="user-info d-flex align-items-center">
                                <img src="../assets/images/<?= $appt['photo'] ?>" alt="User Photo">
                                <div>
                                    <strong><?= $appt['user_name'] ?></strong><br>
                                    <small><?= $appt['appointment_time'] ?></small>
                                </div>
                            </div>
                            <span class="badge bg-warning text-dark">Pending</span>
                        </div>
                        <div class="actions">
                            <form method="POST" action="manage_appointment.php">
                                <input type="hidden" name="appointment_id" value="<?= $appt['id'] ?>">
                                <input type="hidden" name="user_email" value="<?= $appt['email'] ?>">
                                <input type="datetime-local" name="confirmed_time" class="form-control my-2">
                                <button type="submit" name="accept" class="btn btn-success btn-sm w-100">Accept</button>
                                <button type="submit" name="reject" class="btn btn-danger btn-sm w-100">Reject</button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        <?php endwhile; ?>
    </div>

    <!-- Toggle Button to Show/Hide Completed Appointments -->
    <button class="btn btn-primary w-100 my-3" onclick="toggleCompletedAppointments()">
        Show Completed Requests
    </button>

    <div id="completedAppointments" style="display: none;">
        <h4 class="text-primary mt-3">Accepted & Rejected Appointments</h4>
        <div class="row">
            <?php
            // Fetch all appointments again
            $appointments = $conn->query("SELECT a.id, u.username as user_name, u.email, u.phone_no, u.photo, 
                              a.appointment_time, a.status 
                              FROM appointments a 
                              JOIN login u ON a.user_id = u.id 
                              WHERE a.host_id = '$host_id'");
            
            while ($appt = $appointments->fetch_assoc()): ?>
                <?php if ($appt['status'] != 'pending'): ?>
                    <div class="col-md-6">
                        <div class="card shadow-sm">
                            <div class="appointment-card">
                                <div class="user-info d-flex align-items-center">
                                    <img src="../assets/images/<?= $appt['photo'] ?>" alt="User Photo">
                                    <div>
                                        <strong><?= $appt['user_name'] ?></strong><br>
                                        <small><?= $appt['appointment_time'] ?></small>
                                    </div>
                                </div>
                                <span class="badge 
                                    <?= $appt['status'] == 'accepted' ? 'bg-success' : 'bg-danger' ?>">
                                    <?= ucfirst($appt['status']) ?>
                                </span>
                            </div>
                            <?php if ($appt['status'] == 'accepted'): ?>
                                <a href="generate_qr.php?appointment_id=<?= $appt['id'] ?>" class="btn btn-info btn-sm w-100 mt-2">Generate QR</a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endwhile; ?>
        </div>
    </div>

    <h4 class="text-primary mt-4">Manage Appointments</h4>
    <div class="d-flex flex-wrap gap-2">
        <a href="scan_qr.php" class="btn btn-primary btn-sm btn-custom w-100">Scan QR</a>
        <a href="verify_code.php" class="btn btn-secondary btn-sm btn-custom w-100">Verify QR</a>
        <a href="verify_qr.php" class="btn btn-success btn-sm btn-custom w-100">Check In/Out</a>
    </div>
</div>

<script>
function toggleCompletedAppointments() {
    var section = document.getElementById("completedAppointments");
    var button = event.target;

    if (section.style.display === "none") {
        section.style.display = "block";
        button.innerText = "Hide Completed Requests";
    } else {
        section.style.display = "none";
        button.innerText = "Show Completed Requests";
    }
}
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
