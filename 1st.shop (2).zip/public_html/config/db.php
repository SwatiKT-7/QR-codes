
<?php
$host = "localhost"; // Change if needed
$username = "u388482248_v"; // Change as per your database
$password = "Yuv@12345678"; // Change as per your database
$database = "u388482248_e";

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
